<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - AutoCare Maintenance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f8fafc;
        }
        .bg-image {
            background-image: url('assets/images/car_service_bg.png');
            background-size: cover;
            background-position: center;
        }
        .tab-active {
            border-bottom: 2px solid #0f172a;
            color: #0f172a;
            font-weight: 600;
        }
        .tab-inactive {
            border-bottom: 2px solid transparent;
            color: #64748b;
            font-weight: 500;
        }
    </style>
</head>
<body class="min-h-screen flex text-slate-800">

    <div class="hidden lg:flex lg:w-1/2 bg-image relative">
        <div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/30 to-transparent"></div>
        <div class="absolute bottom-12 left-12 right-12 text-white">
            <h2 class="text-4xl font-bold mb-4 tracking-tight leading-tight">Professional Care<br>For Your Vehicle</h2>
            <p class="text-lg text-slate-200 max-w-md">Track services, schedule maintenance, and ensure your vehicle is always in top condition.</p>
        </div>
    </div>

    <div class="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12 bg-white">
        <div class="w-full max-w-md">
            
            <div class="mb-8 text-left">
                <h1 class="text-3xl font-bold text-slate-900 mb-2">Welcome Back</h1>
                <p class="text-slate-500">Please enter your details to sign in.</p>

                <% if(request.getParameter("error") != null) { %>
                    <div class="mt-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm font-medium">
                        <%= request.getParameter("error") %>
                    </div>
                <% } %>
                <% if(request.getParameter("success") != null) { %>
                    <div class="mt-4 p-3 bg-emerald-100 text-emerald-700 rounded-lg text-sm font-medium">
                        <%= request.getParameter("success") %>
                    </div>
                <% } %>
            </div>

            <!-- Tabs -->
            <div class="flex mb-6 border-b border-slate-200">
                <button type="button" id="tabUser" class="flex-1 pb-3 text-center transition-all tab-active" onclick="switchTab('USER')">
                    User Login
                </button>
                <button type="button" id="tabAdmin" class="flex-1 pb-3 text-center transition-all tab-inactive" onclick="switchTab('ADMIN')">
                    Admin Login
                </button>
            </div>

            <form action="LoginServlet" method="POST" class="space-y-5" id="loginForm">
                <!-- Hidden input to determine which tab was used to login -->
                <input type="hidden" id="loginType" name="loginType" value="USER">

                <div>
                    <label for="username" class="block text-sm font-medium text-slate-700 mb-1.5">Username or Email</label>
                    <input type="text" id="username" name="username" required placeholder="Enter your username"
                        class="w-full px-4 py-3.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                </div>

                <div>
                    <label for="password" class="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
                    <input type="password" id="password" name="password" required placeholder="••••••••"
                        class="w-full px-4 py-3.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                </div>

                <div class="flex items-center justify-between pt-2 pb-4">
                    <div class="flex items-center">
                        <input id="remember-me" name="remember-me" type="checkbox"
                            class="h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer transition duration-150">
                        <label for="remember-me" class="ml-2.5 block text-sm text-slate-600 cursor-pointer">
                            Remember me
                        </label>
                    </div>
                    <div class="text-sm">
                        <a href="/forgot-password" class="font-medium text-slate-900 hover:text-blue-600 transition-colors">Forgot password?</a>
                    </div>
                </div>

                <button type="submit" id="submitBtn"
                    class="w-full flex justify-center py-4 px-4 rounded-xl shadow-lg shadow-slate-200/50 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900 transition-all duration-300 transform hover:-translate-y-0.5">
                    Sign In as User
                </button>
            </form>

            <div class="mt-10 text-center text-sm text-slate-500">
                Don't have an account? 
                <a href="/register" class="font-semibold text-slate-900 hover:text-blue-600 transition-colors ml-1">Sign up here</a>
            </div>
        </div>
    </div>

    <script>
        function switchTab(type) {
            document.getElementById('loginType').value = type;
            const tabUser = document.getElementById('tabUser');
            const tabAdmin = document.getElementById('tabAdmin');
            const submitBtn = document.getElementById('submitBtn');

            if (type === 'USER') {
                tabUser.className = 'flex-1 pb-3 text-center transition-all tab-active';
                tabAdmin.className = 'flex-1 pb-3 text-center transition-all tab-inactive';
                submitBtn.innerText = 'Sign In as User';
                submitBtn.className = 'w-full flex justify-center py-4 px-4 rounded-xl shadow-lg shadow-slate-200/50 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900 transition-all duration-300 transform hover:-translate-y-0.5';
            } else {
                tabAdmin.className = 'flex-1 pb-3 text-center transition-all tab-active';
                tabUser.className = 'flex-1 pb-3 text-center transition-all tab-inactive';
                submitBtn.innerText = 'Sign In as Admin';
                submitBtn.className = 'w-full flex justify-center py-4 px-4 rounded-xl shadow-lg shadow-blue-200/50 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-700 transition-all duration-300 transform hover:-translate-y-0.5';
            }
        }
    </script>
</body>
</html>
