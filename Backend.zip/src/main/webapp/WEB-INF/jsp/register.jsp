<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - AutoCare Maintenance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f8fafc;
        }
        .bg-image {
            background-image: url('assets/images/car_service_bg.png');
            background-size: cover;
            background-position: center;
        }
    </style>
</head>
<body class="min-h-screen flex text-slate-800">

    <div class="hidden lg:flex lg:w-5/12 bg-image relative">
        <div class="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent"></div>
        <div class="absolute bottom-12 left-10 right-10 text-white">
            <h2 class="text-3xl font-bold mb-3 tracking-tight leading-tight">Join AutoCare Tracker</h2>
            <p class="text-base text-slate-200 max-w-sm">Create an account to start managing your vehicle's maintenance history.</p>
        </div>
    </div>

    <div class="w-full lg:w-7/12 flex items-center justify-center p-6 sm:p-10 bg-white">
        <div class="w-full max-w-xl">
            <div class="mb-8 text-left">
                <h1 class="text-3xl font-bold text-slate-900 mb-2">Create an Account</h1>
                <p class="text-slate-500">Fill in your details below to get started.</p>
                
                <% if(request.getParameter("error") != null) { %>
                    <div class="mt-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm font-medium">
                        <%= request.getParameter("error") %>
                    </div>
                <% } %>
            </div>

            <!-- Changed action to target RegisterServlet -->
            <form action="RegisterServlet" method="POST" class="space-y-4">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="fullname" class="block text-sm font-medium text-slate-700 mb-1.5">Full Name</label>
                        <input type="text" id="fullname" name="fullname" required placeholder="John Doe"
                            class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                    </div>

                    <div>
                        <label for="username" class="block text-sm font-medium text-slate-700 mb-1.5">Username</label>
                        <input type="text" id="username" name="username" required placeholder="johndoe123"
                            class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                    </div>
                </div>

                <div>
                    <label for="email" class="block text-sm font-medium text-slate-700 mb-1.5">Email Address</label>
                    <input type="email" id="email" name="email" required placeholder="john@example.com"
                        class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label for="password" class="block text-sm font-medium text-slate-700 mb-1.5">Password</label>
                        <input type="password" id="password" name="password" required placeholder="••••••••"
                            class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                    </div>

                    <div>
                        <label for="confirm-password" class="block text-sm font-medium text-slate-700 mb-1.5">Confirm Password</label>
                        <input type="password" id="confirm-password" name="confirm-password" required placeholder="••••••••"
                            class="w-full px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                    </div>
                </div>

                <div class="flex items-start pt-2 pb-4">
                    <div class="flex items-center h-5">
                        <input id="terms" name="terms" type="checkbox" required
                            class="w-4 h-4 rounded border-slate-300 text-slate-900 focus:ring-slate-900 cursor-pointer transition duration-150">
                    </div>
                    <div class="ml-2.5 text-sm">
                        <label for="terms" class="font-medium text-slate-600 cursor-pointer">
                            I agree to the Terms of Service
                        </label>
                    </div>
                </div>

                <button type="submit"
                    class="w-full flex justify-center py-4 px-4 rounded-xl shadow-lg shadow-slate-200/50 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900 transition-all duration-300 transform hover:-translate-y-0.5">
                    Create Account
                </button>
            </form>

            <div class="mt-8 text-center text-sm text-slate-500">
                Already have an account? 
                <a href="/login" class="font-semibold text-slate-900 hover:text-blue-600 transition-colors ml-1">Sign in here</a>
            </div>
        </div>
    </div>

</body>
</html>
