<%@ page import="com.autocare.models.User" %>
<%@ page import="com.autocare.services.UserManager" %>
<%@ page import="java.util.List" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Server-side authentication check for Admin
    User currentUser = (User) session.getAttribute("currentUser");
    if (currentUser == null || !currentUser.getRole().equals("ADMIN")) {
        response.sendRedirect("login.jsp?error=Access Denied. Admins only.");
        return;
    }

    String searchQuery = request.getParameter("searchQuery");
    User searchedUser = null;
    boolean searchPerformed = false;

    if (searchQuery != null && !searchQuery.trim().isEmpty()) {
        UserManager userManager = new UserManager();
        searchedUser = userManager.searchUser(searchQuery.trim());
        searchPerformed = true;
    }

    List<User> allUsers = (List<User>) request.getAttribute("allUsers");
    int totalUsers = (allUsers != null) ? allUsers.size() : 0;
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AutoCare Maintenance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f8fafc;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">

    <nav class="bg-slate-900 text-white p-4 shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="font-bold text-xl flex items-center gap-2">
                <span class="text-blue-500">AutoCare</span> Admin
            </div>
            <div class="flex items-center gap-4">
                <span class="hidden sm:inline-block text-slate-300 font-medium">Admin: <%= currentUser.getFullName().split(" ")[0] %></span>
                <div class="h-8 w-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                    <%= currentUser.getFullName().substring(0, 1).toUpperCase() %>
                </div>
                <form action="LogoutServlet" method="POST" class="m-0">
                    <button type="submit" class="bg-slate-800 hover:bg-red-600 border border-slate-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors ml-2">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <main class="flex-grow max-w-7xl mx-auto w-full p-4 sm:p-8 mt-4">
        
        <div class="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 mb-8 flex flex-col md:flex-row items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-slate-900 mb-2">System Administrator</h1>
                <p class="text-slate-500 mt-1 italic"><%= currentUser.getDashboardAccessLevel() %></p>
            </div>
            <div class="mt-4 md:mt-0 flex gap-3">
                <div class="bg-blue-50 text-blue-700 px-4 py-2 rounded-lg font-medium text-sm">
                    Total Users: <%= totalUsers %>
                </div>
            </div>
        </div>

        <% if(request.getParameter("error") != null) { %>
            <div class="mb-6 p-4 bg-red-100 text-red-700 rounded-xl text-sm font-medium border border-red-200">
                <%= request.getParameter("error") %>
            </div>
        <% } %>
        <% if(request.getParameter("success") != null) { %>
            <div class="mb-6 p-4 bg-emerald-100 text-emerald-700 rounded-xl text-sm font-medium border border-emerald-200">
                <%= request.getParameter("success") %>
            </div>
        <% } %>

        <!-- User Search Section -->
        <div class="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 mb-8">
            <h2 class="text-xl font-bold text-slate-900 mb-4">Search Users</h2>
            <form action="/admin-dashboard" method="GET" class="flex gap-4 max-w-2xl">
                <input type="text" name="searchQuery" placeholder="Enter username or email to search..." value="<%= searchQuery != null ? searchQuery : "" %>"
                    class="flex-1 px-4 py-3 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium shadow-md transition-all">
                    Search
                </button>
                <a href="/admin-dashboard" class="bg-slate-200 hover:bg-slate-300 text-slate-800 px-6 py-3 rounded-xl font-medium transition-all">
                    Clear
                </a>
            </form>

            <!-- Search Results -->
            <% if (searchPerformed) { %>
                <div class="mt-8 border-t border-slate-100 pt-8">
                    <% if (searchedUser != null) { %>
                        <h3 class="text-lg font-semibold text-slate-800 mb-4">User Profile Found:</h3>
                        <div class="bg-slate-50 border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row items-center sm:items-start gap-6 relative overflow-hidden">
                            <div class="absolute top-0 right-0 p-4">
                                <span class="bg-emerald-100 text-emerald-700 text-xs font-bold px-3 py-1 rounded-full"><%= searchedUser.getRole() %></span>
                            </div>
                            <div class="h-20 w-20 rounded-full bg-slate-300 text-slate-600 flex items-center justify-center font-bold text-3xl shrink-0">
                                <%= searchedUser.getFullName().substring(0, 1).toUpperCase() %>
                            </div>
                            <div class="flex-1 text-center sm:text-left">
                                <h4 class="text-2xl font-bold text-slate-900"><%= searchedUser.getFullName() %></h4>
                                <p class="text-slate-500 font-medium mt-1">@<%= searchedUser.getUsername() %></p>
                                
                                <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <p class="text-xs text-slate-400 uppercase tracking-wider font-semibold">Email Address</p>
                                        <p class="text-slate-800 font-medium"><%= searchedUser.getEmail() %></p>
                                    </div>
                                    <div>
                                        <p class="text-xs text-slate-400 uppercase tracking-wider font-semibold">Account ID</p>
                                        <p class="text-slate-800 font-mono text-sm break-all"><%= searchedUser.getId() %></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <% } else { %>
                        <div class="bg-red-50 text-red-600 p-4 rounded-xl border border-red-100 flex items-center justify-center">
                            <p class="font-medium">No user found matching "<%= searchQuery %>".</p>
                        </div>
                    <% } %>
                </div>
            <% } %>
        </div>

        <!-- All Users List Section -->
        <div class="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 mb-8">
            <h2 class="text-xl font-bold text-slate-900 mb-6">Manage All Users</h2>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="border-b border-slate-200 text-slate-500 text-sm tracking-wider uppercase">
                            <th class="py-4 px-4 font-semibold">Name</th>
                            <th class="py-4 px-4 font-semibold">Username</th>
                            <th class="py-4 px-4 font-semibold">Email</th>
                            <th class="py-4 px-4 font-semibold">Role</th>
                            <th class="py-4 px-4 font-semibold text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-slate-700">
                        <% if (allUsers != null && !allUsers.isEmpty()) {
                            for (User u : allUsers) { %>
                                <tr class="hover:bg-slate-50 transition-colors">
                                    <td class="py-4 px-4 font-medium"><%= u.getFullName() %></td>
                                    <td class="py-4 px-4 text-slate-500">@<%= u.getUsername() %></td>
                                    <td class="py-4 px-4"><%= u.getEmail() %></td>
                                    <td class="py-4 px-4">
                                        <span class="px-3 py-1 rounded-full text-xs font-bold 
                                            <%= "ADMIN".equals(u.getRole()) ? "bg-emerald-100 text-emerald-700" : "bg-blue-100 text-blue-700" %>">
                                            <%= u.getRole() %>
                                        </span>
                                    </td>
                                    <td class="py-4 px-4 text-right">
                                        <% if (!u.getId().equals(currentUser.getId())) { %>
                                            <form action="/delete-user" method="POST" class="inline m-0" onsubmit="return confirm('Are you sure you want to delete user @<%= u.getUsername() %>? This action cannot be undone.');">
                                                <input type="hidden" name="userId" value="<%= u.getId() %>">
                                                <button type="submit" class="text-red-600 hover:text-red-800 hover:bg-red-50 px-3 py-1.5 rounded-lg font-medium text-sm transition-colors border border-transparent hover:border-red-200">Delete</button>
                                            </form>
                                        <% } else { %>
                                            <span class="text-slate-400 font-medium text-sm italic px-3 py-1.5">Current Admin</span>
                                        <% } %>
                                    </td>
                                </tr>
                        <%  }
                           } else { %>
                            <tr>
                                <td colspan="5" class="py-8 text-center text-slate-500 italic">No users found in the system.</td>
                            </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>

    </main>

</body>
</html>
