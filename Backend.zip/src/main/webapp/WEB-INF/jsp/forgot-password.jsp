<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - AutoCare Maintenance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f8fafc;
        }
        .bg-image {
            background-image: url('assets/images/car_service_bg.png');
            background-size: cover;
            background-position: center;
        }
    </style>
</head>
<body class="min-h-screen flex text-slate-800">

    <div class="hidden lg:flex lg:w-1/2 bg-image relative">
        <div class="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/30 to-transparent"></div>
        <div class="absolute bottom-12 left-12 right-12 text-white">
            <h2 class="text-4xl font-bold mb-4 tracking-tight leading-tight">Professional Care<br>For Your Vehicle</h2>
            <p class="text-lg text-slate-200 max-w-md">Track services, schedule maintenance, and ensure your vehicle is always in top condition.</p>
        </div>
    </div>

    <div class="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12 bg-white">
        <div class="w-full max-w-md">
            
            <div class="mb-10 text-left">
                <h1 class="text-3xl font-bold text-slate-900 mb-2">Reset Password</h1>
                <p class="text-slate-500">Enter your username or email and your new password.</p>

                <% if(request.getParameter("error") != null) { %>
                    <div class="mt-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm font-medium">
                        <%= request.getParameter("error") %>
                    </div>
                <% } %>
            </div>

            <!-- Action targets ResetPasswordServlet -->
            <form action="ResetPasswordServlet" method="POST" class="space-y-5">
                <div>
                    <label for="username" class="block text-sm font-medium text-slate-700 mb-1.5">Username or Email</label>
                    <input type="text" id="username" name="username" required placeholder="Enter your username or email"
                        class="w-full px-4 py-3.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                </div>

                <div>
                    <label for="newPassword" class="block text-sm font-medium text-slate-700 mb-1.5">New Password</label>
                    <input type="password" id="newPassword" name="newPassword" required placeholder="••••••••"
                        class="w-full px-4 py-3.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                </div>

                <div>
                    <label for="confirmPassword" class="block text-sm font-medium text-slate-700 mb-1.5">Confirm New Password</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" required placeholder="••••••••"
                        class="w-full px-4 py-3.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:bg-white transition-all duration-200">
                </div>

                <button type="submit"
                    class="w-full flex justify-center py-4 px-4 mt-8 rounded-xl shadow-lg shadow-slate-200/50 text-sm font-semibold text-white bg-slate-900 hover:bg-slate-800 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-slate-900 transition-all duration-300 transform hover:-translate-y-0.5">
                    Reset Password
                </button>
            </form>

            <div class="mt-10 text-center text-sm text-slate-500">
                Remember your password? 
                <a href="/login" class="font-semibold text-slate-900 hover:text-blue-600 transition-colors ml-1">Sign in here</a>
            </div>
        </div>
    </div>

</body>
</html>
