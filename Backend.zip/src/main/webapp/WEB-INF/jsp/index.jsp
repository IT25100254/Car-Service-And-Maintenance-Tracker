<%@ page import="com.autocare.models.User" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Server-side authentication check
    User currentUser = (User) session.getAttribute("currentUser");
    if (currentUser == null) {
        response.sendRedirect("/login");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - AutoCare Maintenance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background-color: #f8fafc;
        }
    </style>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">

    <nav class="bg-slate-900 text-white p-4 shadow-md sticky top-0 z-50">
        <div class="max-w-7xl mx-auto flex justify-between items-center">
            <div class="font-bold text-xl flex items-center gap-2">
                AutoCare Tracker
            </div>
            <div class="flex items-center gap-4">
                <span class="hidden sm:inline-block text-slate-300 font-medium">Welcome, <%= currentUser.getFullName().split(" ")[0] %></span>
                <div class="h-8 w-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm">
                    <%= currentUser.getFullName().substring(0, 1).toUpperCase() %>
                </div>
                <!-- Call LogoutServlet -->
                <form action="LogoutServlet" method="POST" class="m-0">
                    <button type="submit" class="bg-slate-800 hover:bg-slate-700 border border-slate-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors ml-2">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <main class="flex-grow max-w-7xl mx-auto w-full p-4 sm:p-8 mt-4">
        
        <div class="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 mb-8 flex flex-col md:flex-row items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-slate-900 mb-2">Welcome Back, <%= currentUser.getFullName().split(" ")[0] %>!</h1>
                <p class="text-slate-500">Your Role: <span class="font-bold text-blue-600"><%= currentUser.getRole() %></span></p>
                <p class="text-slate-500 mt-1 italic"><%= currentUser.getDashboardAccessLevel() %></p>
            </div>
            <% if(currentUser.getRole().equals("ADMIN")) { %>
                <button class="mt-4 md:mt-0 bg-amber-600 hover:bg-amber-700 text-white px-6 py-3 rounded-xl font-medium shadow-lg transition-all">
                    Manage System Users
                </button>
            <% } else { %>
                <button class="mt-4 md:mt-0 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium shadow-lg transition-all">
                    + Add New Vehicle
                </button>
            <% } %>
        </div>

    </main>

</body>
</html>
